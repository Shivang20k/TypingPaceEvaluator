This is a Full Packaged "PROCTORING AND TYPING PACE EVALUATOR".
It is a project which works for giving a application for TYPING SPEED EVALUATION it has bunch of features which are listed as follow-

1. This app provides a convenient interface for typing speed evaluation by having it supported 
   by PYTHON'S Tkinter library.

2. In this app we a feature where we can Dictate a passage or paragraph for which typing test
   is done else we have some good pre-setted testing paragraphs.

3. We used "Speech Recognition" as well as "PYTTSX3" which enables our application to speak and listen on own.

4. This application provides stats like WordsPerMinute(WPM), Time Taken & Accuracy check for user.

5. We have the feature to store the results of user so that one can measure it's record after each attempt.

6. Now, the major feature is that it has a proctoring system in it.
   Which means that at the time of logging in the application face recognition is done and at the time of exam this application can predict that user is authentic.

These all features makes this TYPING PACE EVALUATOR a ready to use and super easy to interact application